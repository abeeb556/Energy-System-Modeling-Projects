import comando
from comando.utility import define_function

default_bounds = {
    'P': (-6, 6),
    'Q': (-3, 3),
    'u': (0.9, 1.1),
    'theta': (-10, 10)
}

DC_default_bounds = {
    'P': (-10, 10),
    'Q': (0, 0),
    'u': (1, 1),
    'theta': (-0.3, 0.3)
}


def norm2_implementation(x, y):
    """Calculate the euclidian norm (x**2 + y**2) ** 0.5 for x and y."""
    return (x ** 2 + y ** 2) ** 0.5


norm2 = define_function('norm2', norm2_implementation)


class Bus(comando.System):
    """A basic Bus model.

    A bus is specified by a label and the quantities that have known values.
    These quantities may be P, Q, U, or theta, corresponding to:
    - active power [MW]
    - reactive power [MVAr]
    - voltage [p.u.]
    - phase angle [deg]

    If the value of the given quantity is static, it can be given directly via
    a kwarg. If instead it changes with time, the value may be given after the
    specification of the time discretization for the problem to be solved.

    Arguments
    ---------
    label : str
        the label of the line
    U_base : float
        bus base voltage [kV]
    *given : tuple of str
        the names of quantities for which values will be specified
    **given_with_data : dict of str -> float
        the name and value of fixed quantities
    """

    def __init__(self, label, *given, U_base=10, DC=False, **given_with_data):
        super().__init__(label)
        self.U_base = U_base
        quantities = {'P', 'Q', 'u', 'theta'}
        assert all(arg in quantities for arg in (*given, *given_with_data)), \
            "Only quantities P, Q, u, or theta may be given!"
        given_with_data.update({q: None for q in given})
        for q in quantities:
            value = given_with_data.get(q, None)
            try:
                value = float(value)
                self.make_parameter(q, value=value)
            except TypeError:
                if value is None:
                    if not DC:
                        self.make_operational_variable(q, bounds=default_bounds[q],
                                                       init_val=0.5 * sum(default_bounds[q]))
                    else:
                        self.make_operational_variable(q, bounds=DC_default_bounds[q],
                                                       init_val=0.5 * sum(DC_default_bounds[q]))
                else:
                    self.add_expression(q, value)

        self.add_connector('P', self['P'])
        self.add_connector('Q', self['Q'])

        self.given = given_with_data.keys()

    def __repr__(self):
        if self.given == {'P', 'Q'}:
            return f"PQ bus {self.label}"
        if self.given == {'P', 'u'}:
            return f"PV bus {self.label}"
        if self.given == {'u', 'theta'}:
            return f"Slack bus {self.label}"
        else:
            return f"Generic bus {self.label}"


class AC_Line(comando.Component):
    """A basic π-line model.

    A π-line is specified by a label, the 'from' and the 'to' bus objects, and
    the line parameters r, x, b_shunt, a, and phi.
    Optionally, the line current I [kA] and apparent power flow S [MVA] may be
    limited by specifying I_rate, or S_rate, respectively.

    Arguments
    ---------
    label : str
       the label of the line
    from, to : Bus
       the `Bus` objects the line connects
    S_base : float
        system base apparent power [MVA]
    r : float
        line resistance [p.u.]
    x : float
        line reactance [p.u.]
    b_shunt : float
        shunt susceptance [p.u.]
    a : float
        tap ratio [ -- ]
    phi : float
        phase angle shift [deg]
    I_rate : float
       (optional) maximum allowable current [kA]
    S_rate : float
       (optional) maximum allowable apparent power flow [MVA]
    """

    def __init__(self, label, S_base, fbus, tbus, r, x,
                 b_shunt=0, a=1, phi=0, I_rate=None, S_rate=None):
        # NOTE: using caps names to distinguish from numpy functions
        def deg2rad(deg):
            from numpy import pi
            return deg * pi / 180

        def Cos(deg):
            """Object representing Cosine function, taking values in degrees."""
            from comando import cos
            return cos(deg2rad(deg))

        def Sin(deg):
            """Object representing Sine function, taking values in degrees."""
            from comando import sin
            return sin(deg2rad(deg))

        super().__init__(label)

        self.fbus = fbus
        self.tbus = tbus
        self.r = r
        self.x = x
        self.b_shunt = b_shunt
        self.a = a
        self.phi = phi
        self.I_rate = I_rate
        self.S_rate = S_rate

        u_fbus = fbus['u'] / a
        u_tbus = tbus['u']

        theta_fbus = fbus['theta']
        theta_tbus = tbus['theta']
        # NOTE: This is theta for the from - to direction, the theta for the
        #       reverse direction is -theta so the Sin changes its sign!
        theta = theta_fbus - theta_tbus - phi

        u_prod = u_fbus * u_tbus

        z = complex(r, x)  # impedance
        y = 1 / z  # admittance
        Y_shunt = complex(0, b_shunt)  # shunt admittance
        g = y.real
        b = y.imag
        # g = a * (y.real * Cos(phi) - y.imag * Sin(phi))
        # b = a * (y.imag * Cos(phi) + y.real * Sin(phi))

        P_main_fbus = S_base * u_prod * (-g * Cos(theta) - b * Sin(theta))
        P_main_tbus = S_base * u_prod * (-g * Cos(theta) + b * Sin(theta))
        P_fbus_shunt = S_base * u_fbus ** 2 * g
        P_tbus_shunt = S_base * u_tbus ** 2 * g

        # active power flows from the buses to the center of the line
        P_fbus = self.add_expression('P_fbus', P_main_fbus + P_fbus_shunt)
        P_tbus = self.add_expression('P_tbus', P_main_tbus + P_tbus_shunt)

        Q_main_fbus = S_base * u_prod * (-g * Sin(theta) + b * Cos(theta))
        Q_main_tbus = S_base * u_prod * (g * Sin(theta) + b * Cos(theta))
        Q_fbus_shunt = -S_base * u_fbus ** 2 * (b + 0.5 * b_shunt)
        Q_tbus_shunt = -S_base * u_tbus ** 2 * (b + 0.5 * b_shunt)

        # reactive power flows from the buses to the center of the line
        Q_fbus = self.add_expression('Q_fbus', Q_main_fbus + Q_fbus_shunt)
        Q_tbus = self.add_expression('Q_tbus', Q_main_tbus + Q_tbus_shunt)

        self.add_expression('P_loss', P_fbus + P_tbus)
        self.add_expression('Q_loss_2', Q_fbus + Q_tbus)
        self.add_expression('Q_loss', Q_main_fbus + Q_main_tbus - S_base * b * (u_fbus ** 2 + u_tbus ** 2))
        # self.add_expression('Q_loss', Q_fbus + Q_tbus + S_base * (u_tbus ** 2 + u_fbus ** 2) * 0.5 * b_shunt)

        S_fbus = self.add_expression('S_fbus', norm2(P_fbus, Q_fbus))
        S_tbus = self.add_expression('S_tbus', norm2(P_tbus, Q_tbus))

        U_fbus = self.add_expression('U_fbus', u_fbus * fbus.U_base)
        U_tbus = self.add_expression('U_fbus', u_tbus * tbus.U_base)

        inv_sqrt3 = 3 ** -0.5
        I_fbus = self.add_expression('I_fbus',
                                     S_fbus * inv_sqrt3 / U_fbus)
        I_tbus = self.add_expression('I_tbus',
                                     S_tbus * inv_sqrt3 / U_tbus)
        # If required arguments were given, introduce capacity constraints
        if I_rate is not None:
            self.add_le_constraint(I_fbus, I_rate, 'I_rate_from')
            self.add_le_constraint(I_tbus, I_rate, 'I_rate_to')
        if S_rate is not None:
            self.add_le_constraint(S_fbus, S_rate, 'S_rate_from')
            self.add_le_constraint(S_tbus, S_rate, 'S_rate_to')

        self.add_connector('P_TO', P_tbus)
        self.add_connector('Q_TO', Q_tbus)
        self.add_connector('P_FROM', P_fbus)
        self.add_connector('Q_FROM', Q_fbus)


class DC_Line(comando.Component):
    """A basic line with the simplifications for DC Power Flow

    The line is specified by a label, the 'from' and the 'to' bus objects, and
    the line parameters x and phi (r, b_shunt and a can be neglected)
    Optionally, the line current I [kA] and apparent power flow S [MVA] may be
    limited by specifying I_rate, or S_rate, respectively.

    Arguments
    ---------
    label : str
       the label of the line
    from, to : Bus
       the `Bus` objects the line connects
    S_base : float
        system base apparent power [MVA]
    x : float
        line reactance [p.u.]
    phi : float
        phase angle shift [deg]
    I_rate : float
       (optional) maximum allowable current [kA]
    S_rate : float
       (optional) maximum allowable apparent power flow [MVA]
    """

    def __init__(self, label, S_base, fbus, tbus, x, phi=0, I_rate=None, S_rate=None, r=None, b_shunt=None, a=None):

        super().__init__(label)

        for qn, q in dict(r=r, b_shunt=b_shunt, a=a).items():
            if q is not None:
                print(f'WARNING: Ignoring value {q} for quantity {qn}')

        self.fbus = fbus
        self.tbus = tbus
        self.x = x
        self.phi = phi
        self.I_rate = I_rate
        self.S_rate = S_rate

        theta_fbus = fbus['theta']
        theta_tbus = tbus['theta']
        # NOTE: This is theta for the from - to direction, the theta for the
        #       reverse direction is -theta so the Sin changes its sign!
        theta = theta_fbus - theta_tbus - phi
        b = -1 / x  # - due to complex numbers (1/j = -j)

        P_fbus = self.add_expression('P_fbus', S_base * -1 * b * theta)
        P_tbus = self.add_expression('P_tbus', S_base * b * theta)

        if S_rate is not None:
            self.add_le_constraint(P_fbus, S_rate, 'S_rate_from')
            self.add_le_constraint(P_tbus, S_rate, 'S_rate_to')

        self.add_connector('P_TO', P_tbus)
        self.add_connector('P_FROM', P_fbus)


class NTC_Line(comando.Component):

    def __init__(self, label, S_base, fbus, tbus, S_rate=None, I_rate=None, x=None, phi=None,
                 r=None, b_shunt=None, a=None):

        super().__init__(label)

        for qn, q in dict(x=x, phi=phi, r=r, b_shunt=b_shunt, a=a).items():
            if q is not None:
                print(f'WARNING: Ignoring value {q} for quantity {qn}')

        self.fbus = fbus
        self.tbus = tbus
        self.I_rate = I_rate
        self.S_rate = S_rate

        inv_sqrt3 = 3 ** -0.5
        P_fbus = self.make_operational_variable('P_fbus')
        I_fbus = self.add_expression('I_fbus', P_fbus * inv_sqrt3 / fbus.U_base)

        if S_rate is not None:
            self.add_le_constraint(P_fbus, S_rate, 'S_rate_from')
            self.add_le_constraint(-S_rate, P_fbus, 'S_rate_to')

        if I_rate is not None:
            self.add_le_constraint(I_fbus, I_rate, 'I_rate_from')
            self.add_le_constraint(-I_rate, I_fbus, 'I_rate_to')

        P_tbus = self.add_expression('P_tbus', -P_fbus)

        self.add_connector('P_TO', P_tbus)
        self.add_connector('P_FROM', P_fbus)


class PowerSystem(comando.System):
    """A basic power system specified via the available lines.

    A line is defined by a label and 5 or 6 additional quantities, namely:
    - Label of 'from' bus
    - Label of 'to' bus
    - resistance [Ω]
    - reactance [Ω]
    - shunt susceptance [S]
    - (optional) Maximum allowable power flow [W]

    The line names are automatically generated from the buses they connect, the
    remaining data needs to be passed as an iterable of iterables.

    Arguments
    ---------
    label : str
        the label of the system
    line_data : dict
        line parameters
    bus_data : dict
        bus_parameters
    S_base : float
        system base apparent power [MVA]
    """

    def __init__(self, label, line_data, bus_data=None, S_base=1, kind='AC'):
        from collections import defaultdict
        super().__init__(label)

        allowed_kinds = {'AC', 'DC', 'NTC'}
        if kind not in allowed_kinds:
            raise ValueError(f'kind should be one of {allowed_kinds}, '
                             f'was {kind}!')
        Line = globals()[f'{kind}_Line']
        self.kind = kind

        self.buses = {}
        self.lines = {}
        conn = {}
        if bus_data is None:
            bus_data = defaultdict(dict)
        else:
            bus_data = defaultdict(dict, bus_data)

        def lookup_or_create(name):
            """Look up bus with given name or create it if it doesn't exist."""
            if name in self.buses:
                return self.buses[name]
            else:
                bus = Bus(name, **(bus_data[name]))
                self.add(bus)
                self.buses[name] = bus
                return bus
            # return self.buses.setdefault(name, Bus(name, **(bus_data[name])))

        for (f_name, t_name), data in line_data.items():
            # f_name, t_name, *pars = data

            f_bus = lookup_or_create(f_name)
            t_bus = lookup_or_create(t_name)
            line_name = f"L_{f_name}_{t_name}"
            self.lines[line_name] = line = Line(line_name, S_base,
                                                f_bus, t_bus, **data)
            self.add(line)

            conn.setdefault(f'{f_name}_P', []).append(line.P_FROM)
            conn.setdefault(f'{t_name}_P', []).append(line.P_TO)
            if self.kind == 'AC':
                conn.setdefault(f'{f_name}_Q', []).append(line.Q_FROM)
                conn.setdefault(f'{t_name}_Q', []).append(line.Q_TO)

        for bus_name, bus in self.buses.items():
            conn[f'{bus_name}_P'].append(bus.P)
            if self.kind == 'AC':
                conn[f'{bus_name}_Q'].append(bus.Q)

        for bus_name, connections in conn.items():
            self.connect(bus_name, connections)

    def create_OPF_problem(self, poly_params=None, exclude=(),
                           timesteps=(['nominal'], 1)):
        """Create an OPF problem with polynomial cost function.

        The polynomial is defined via a dict of powers and coefficents, labels
        of buses that should be excluded can be given.
        """
        obj = 0
        if poly_params is None:
            poly_params = {0: 150, 1: 5, 2: 0.11}

        def poly(v):
            return sum(c * v ** p for p, c in poly_params.items())

        for bus_name in self.buses:
            if bus_name in exclude:
                continue
            for q in 'P', 'Q':
                v = -self[f'{bus_name}_{q}']
                obj += poly(v)

        P = self.create_problem(0, obj, timesteps=timesteps)

        def solve(solver='maingo', **options):
            if solver == 'maingo':
                from comando.interfaces.maingo_api import MaingoProblem
                mp = MaingoProblem(P)
                return mp.solve(**options)
            if solver == 'couenne':
                # Solve via couenne, interfaced via Pyomo
                from comando.interfaces.pyomo import to_pyomo, pyomo_op_map
                pyomo_op_map['norm2'] = norm2_implementation
                m = to_pyomo(P)
                # NOTE: Bounds in 'Problem' section of summary are incorrect, as
                #       Pyomo does not parse couenne's results correctly.
                return m.solve('couenne', **options)
            raise NotImplementedError('No routine implemented '
                                      f'for solver {solver}!')

        P.solve = solve
        return P

